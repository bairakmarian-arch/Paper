package com.paperapp.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.io.FileOutputStream

class Repository(private val context: Context) {
    private val database = AppDatabase.getDatabase(context)
    private val journalDao = database.journalDao()
    private val pageDao = database.pageDao()
    
    val allJournals: Flow<List<Journal>> = journalDao.getAllJournals()
    
    fun getPagesByJournalId(journalId: Long): Flow<List<Page>> {
        return pageDao.getPagesByJournalId(journalId)
    }
    
    suspend fun createJournal(title: String, coverUri: Uri? = null): Long {
        val coverPath = coverUri?.let { saveImageToInternalStorage(it, "cover_${System.currentTimeMillis()}") }
        val journal = Journal(title = title, coverImagePath = coverPath)
        return journalDao.insertJournal(journal)
    }
    
    suspend fun updateJournal(journal: Journal) {
        journalDao.updateJournal(journal.copy(updatedAt = System.currentTimeMillis()))
    }
    
    suspend fun deleteJournal(journal: Journal) {
        // Delete associated images
        journal.coverImagePath?.let { deleteImageFile(it) }
        val pages = pageDao.getPagesByJournalId(journal.id)
        journalDao.deleteJournal(journal)
    }
    
    suspend fun getJournalById(journalId: Long): Journal? {
        return journalDao.getJournalById(journalId)
    }
    
    suspend fun addPageToJournal(journalId: Long, imageUri: Uri): Long {
        val imagePath = saveImageToInternalStorage(imageUri, "page_${System.currentTimeMillis()}")
        val maxOrder = pageDao.getMaxOrderIndex(journalId) ?: -1
        val page = Page(
            journalId = journalId,
            imagePath = imagePath,
            orderIndex = maxOrder + 1
        )
        val pageId = pageDao.insertPage(page)
        
        // Update journal's updatedAt timestamp
        val journal = journalDao.getJournalById(journalId)
        journal?.let {
            journalDao.updateJournal(it.copy(updatedAt = System.currentTimeMillis()))
        }
        
        return pageId
    }
    
    suspend fun deletePage(page: Page) {
        deleteImageFile(page.imagePath)
        pageDao.deletePage(page)
    }
    
    private fun saveImageToInternalStorage(uri: Uri, filename: String): String {
        val imagesDir = File(context.filesDir, "images")
        if (!imagesDir.exists()) {
            imagesDir.mkdirs()
        }
        
        val imageFile = File(imagesDir, filename)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(imageFile).use { output ->
                input.copyTo(output)
            }
        }
        
        return imageFile.absolutePath
    }
    
    private fun deleteImageFile(path: String) {
        try {
            File(path).delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
