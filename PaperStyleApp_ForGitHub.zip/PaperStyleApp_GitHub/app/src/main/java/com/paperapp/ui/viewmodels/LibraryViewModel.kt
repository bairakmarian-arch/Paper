package com.paperapp.ui.viewmodels

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.paperapp.data.Journal
import com.paperapp.data.Repository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LibraryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = Repository(application)
    
    val journals: StateFlow<List<Journal>> = repository.allJournals
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    
    fun createJournal(title: String, coverUri: Uri?) {
        viewModelScope.launch {
            repository.createJournal(title, coverUri)
        }
    }
    
    fun deleteJournal(journal: Journal) {
        viewModelScope.launch {
            repository.deleteJournal(journal)
        }
    }
}
