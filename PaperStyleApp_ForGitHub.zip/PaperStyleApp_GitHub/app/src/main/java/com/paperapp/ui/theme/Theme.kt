package com.paperapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Paper-inspired color palette
private val PaperWhite = Color(0xFFFAFAFA)
private val PaperGray = Color(0xFFE8E8E8)
private val PaperDarkGray = Color(0xFF6B6B6B)
private val PaperBlack = Color(0xFF2C2C2C)
private val PaperAccent = Color(0xFF4A90E2)

private val LightColorScheme = lightColorScheme(
    primary = PaperBlack,
    onPrimary = PaperWhite,
    secondary = PaperAccent,
    onSecondary = PaperWhite,
    background = PaperWhite,
    onBackground = PaperBlack,
    surface = PaperWhite,
    onSurface = PaperBlack,
    surfaceVariant = PaperGray,
    onSurfaceVariant = PaperDarkGray,
    outline = PaperGray
)

@Composable
fun PaperAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = PaperTypography,
        content = content
    )
}
