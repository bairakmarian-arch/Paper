package com.paperapp.ui.viewmodels

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.paperapp.data.Journal
import com.paperapp.data.Page
import com.paperapp.data.Repository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JournalViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = Repository(application)
    
    private val _currentJournal = MutableStateFlow<Journal?>(null)
    val currentJournal: StateFlow<Journal?> = _currentJournal.asStateFlow()
    
    private val _pages = MutableStateFlow<List<Page>>(emptyList())
    val pages: StateFlow<List<Page>> = _pages.asStateFlow()
    
    private var currentJournalId: Long? = null
    
    fun loadJournal(journalId: Long) {
        currentJournalId = journalId
        viewModelScope.launch {
            _currentJournal.value = repository.getJournalById(journalId)
            
            repository.getPagesByJournalId(journalId).collect { pagesList ->
                _pages.value = pagesList
            }
        }
    }
    
    fun addPage(imageUri: Uri) {
        currentJournalId?.let { journalId ->
            viewModelScope.launch {
                repository.addPageToJournal(journalId, imageUri)
            }
        }
    }
    
    fun deletePage(page: Page) {
        viewModelScope.launch {
            repository.deletePage(page)
        }
    }
}
