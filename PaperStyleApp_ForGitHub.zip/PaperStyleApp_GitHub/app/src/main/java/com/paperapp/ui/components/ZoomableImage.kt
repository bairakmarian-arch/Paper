package com.paperapp.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector2D
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ZoomableImage(
    imagePath: String,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val coroutineScope = rememberCoroutineScope()
    
    val animatedScale = remember { Animatable(1f) }
    val animatedOffset = remember { Animatable(Offset.Zero, Offset.VectorConverter) }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (scale * zoom).coerceIn(1f, 5f)
                    
                    if (newScale > 1f) {
                        // Calculate new offset with bounds
                        val maxX = (size.width * (newScale - 1)) / 2f
                        val maxY = (size.height * (newScale - 1)) / 2f
                        
                        val newOffset = offset + pan
                        offset = Offset(
                            x = newOffset.x.coerceIn(-maxX, maxX),
                            y = newOffset.y.coerceIn(-maxY, maxY)
                        )
                    } else {
                        offset = Offset.Zero
                    }
                    
                    scale = newScale
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { tapOffset ->
                        coroutineScope.launch {
                            if (scale > 1f) {
                                // Zoom out
                                animatedScale.animateTo(
                                    targetValue = 1f,
                                    animationSpec = spring()
                                )
                                animatedOffset.animateTo(
                                    targetValue = Offset.Zero,
                                    animationSpec = spring()
                                )
                                scale = 1f
                                offset = Offset.Zero
                            } else {
                                // Zoom in to tap location
                                val targetScale = 2.5f
                                
                                // Calculate offset to center on tap point
                                val centerX = size.width / 2f
                                val centerY = size.height / 2f
                                val offsetX = (centerX - tapOffset.x) * (targetScale - 1)
                                val offsetY = (centerY - tapOffset.y) * (targetScale - 1)
                                
                                val maxX = (size.width * (targetScale - 1)) / 2f
                                val maxY = (size.height * (targetScale - 1)) / 2f
                                
                                val targetOffset = Offset(
                                    x = offsetX.coerceIn(-maxX, maxX),
                                    y = offsetY.coerceIn(-maxY, maxY)
                                )
                                
                                animatedScale.animateTo(
                                    targetValue = targetScale,
                                    animationSpec = spring()
                                )
                                animatedOffset.animateTo(
                                    targetValue = targetOffset,
                                    animationSpec = spring()
                                )
                                scale = targetScale
                                offset = targetOffset
                            }
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = File(imagePath),
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                ),
            contentScale = ContentScale.Fit
        )
    }
}
