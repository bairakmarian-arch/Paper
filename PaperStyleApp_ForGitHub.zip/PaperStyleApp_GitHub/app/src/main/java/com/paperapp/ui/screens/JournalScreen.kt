package com.paperapp.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.paperapp.data.Page
import com.paperapp.ui.components.ZoomableImage
import com.paperapp.ui.viewmodels.JournalViewModel
import java.io.File

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(
    journalId: Long,
    viewModel: JournalViewModel,
    onBackClick: () -> Unit
) {
    LaunchedEffect(journalId) {
        viewModel.loadJournal(journalId)
    }
    
    val journal by viewModel.currentJournal.collectAsState()
    val pages by viewModel.pages.collectAsState()
    var showUI by remember { mutableStateOf(true) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var pageToDelete by remember { mutableStateOf<Page?>(null) }
    
    val pagerState = rememberPagerState(pageCount = { pages.size })
    
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            viewModel.addPage(it)
        }
    }
    
    Box(modifier = Modifier.fillMaxSize()) {
        if (pages.isEmpty()) {
            EmptyJournalState(
                journalTitle = journal?.title ?: "",
                onAddClick = { imagePickerLauncher.launch("image/*") },
                onBackClick = onBackClick
            )
        } else {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { showUI = !showUI }
                        )
                    }
            ) { pageIndex ->
                val page = pages[pageIndex]
                ZoomableImage(
                    imagePath = page.imagePath,
                    modifier = Modifier.fillMaxSize()
                )
            }
            
            // UI overlay with animation
            androidx.compose.animation.AnimatedVisibility(
                visible = showUI,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Top bar
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    journal?.title ?: "",
                                    style = MaterialTheme.typography.titleLarge
                                )
                                if (pages.isNotEmpty()) {
                                    Text(
                                        "Страница ${pagerState.currentPage + 1} из ${pages.size}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onBackClick) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Назад"
                                )
                            }
                        },
                        actions = {
                            if (pages.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        pageToDelete = pages[pagerState.currentPage]
                                        showDeleteDialog = true
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Удалить страницу"
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Black.copy(alpha = 0.7f),
                            titleContentColor = Color.White,
                            navigationIconContentColor = Color.White,
                            actionIconContentColor = Color.White
                        )
                    )
                    
                    Spacer(modifier = Modifier.weight(1f))
                    
                    // Bottom action bar
                    Surface(
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            ExtendedFloatingActionButton(
                                onClick = { imagePickerLauncher.launch("image/*") },
                                icon = {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Добавить страницу"
                                    )
                                },
                                text = { Text("Добавить страницу") },
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
    
    if (showDeleteDialog && pageToDelete != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Удалить страницу?") },
            text = { Text("Это действие нельзя отменить.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        pageToDelete?.let { viewModel.deletePage(it) }
                        showDeleteDialog = false
                        pageToDelete = null
                    }
                ) {
                    Text("Удалить", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    pageToDelete = null
                }) {
                    Text("Отмена")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmptyJournalState(
    journalTitle: String,
    onAddClick: () -> Unit,
    onBackClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(journalTitle) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp),
                modifier = Modifier.padding(48.dp)
            ) {
                Text(
                    text = "Журнал пуст",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = "Добавьте первую страницу",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
                
                FilledTonalButton(
                    onClick = onAddClick,
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Добавить страницу")
                }
            }
        }
    }
}
