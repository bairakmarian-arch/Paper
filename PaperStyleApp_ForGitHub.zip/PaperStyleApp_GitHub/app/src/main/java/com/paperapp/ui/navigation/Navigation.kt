package com.paperapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.paperapp.ui.screens.JournalScreen
import com.paperapp.ui.screens.LibraryScreen
import com.paperapp.ui.viewmodels.JournalViewModel
import com.paperapp.ui.viewmodels.LibraryViewModel

sealed class Screen(val route: String) {
    object Library : Screen("library")
    object Journal : Screen("journal/{journalId}") {
        fun createRoute(journalId: Long) = "journal/$journalId"
    }
}

@Composable
fun AppNavigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Library.route
    ) {
        composable(Screen.Library.route) {
            val viewModel: LibraryViewModel = viewModel()
            LibraryScreen(
                viewModel = viewModel,
                onJournalClick = { journalId ->
                    navController.navigate(Screen.Journal.createRoute(journalId))
                }
            )
        }
        
        composable(
            route = Screen.Journal.route,
            arguments = listOf(
                navArgument("journalId") {
                    type = NavType.LongType
                }
            )
        ) { backStackEntry ->
            val journalId = backStackEntry.arguments?.getLong("journalId") ?: return@composable
            val viewModel: JournalViewModel = viewModel()
            
            JournalScreen(
                journalId = journalId,
                viewModel = viewModel,
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }
    }
}
