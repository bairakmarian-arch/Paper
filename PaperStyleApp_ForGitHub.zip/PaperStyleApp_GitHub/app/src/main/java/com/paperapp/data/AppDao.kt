package com.paperapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface JournalDao {
    @Query("SELECT * FROM journals ORDER BY updatedAt DESC")
    fun getAllJournals(): Flow<List<Journal>>
    
    @Query("SELECT * FROM journals WHERE id = :journalId")
    suspend fun getJournalById(journalId: Long): Journal?
    
    @Insert
    suspend fun insertJournal(journal: Journal): Long
    
    @Update
    suspend fun updateJournal(journal: Journal)
    
    @Delete
    suspend fun deleteJournal(journal: Journal)
}

@Dao
interface PageDao {
    @Query("SELECT * FROM pages WHERE journalId = :journalId ORDER BY orderIndex ASC")
    fun getPagesByJournalId(journalId: Long): Flow<List<Page>>
    
    @Query("SELECT * FROM pages WHERE id = :pageId")
    suspend fun getPageById(pageId: Long): Page?
    
    @Insert
    suspend fun insertPage(page: Page): Long
    
    @Insert
    suspend fun insertPages(pages: List<Page>)
    
    @Update
    suspend fun updatePage(page: Page)
    
    @Delete
    suspend fun deletePage(page: Page)
    
    @Query("SELECT MAX(orderIndex) FROM pages WHERE journalId = :journalId")
    suspend fun getMaxOrderIndex(journalId: Long): Int?
}
