package com.paperapp.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "pages",
    foreignKeys = [ForeignKey(
        entity = Journal::class,
        parentColumns = ["id"],
        childColumns = ["journalId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("journalId")]
)
data class Page(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val journalId: Long,
    val imagePath: String,
    val orderIndex: Int,
    val createdAt: Long = System.currentTimeMillis()
)
